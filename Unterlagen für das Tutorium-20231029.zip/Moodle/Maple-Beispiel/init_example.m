%%%% Initialization template

%% Parameters
% Parameter 1
p1 = 0.5;
p2 = 1/3;
params = [p1 p2];
clear p1 p2

%% Initial conditions
% First-Order Dynamic system 1
x1_ic = [3;-5;4];

